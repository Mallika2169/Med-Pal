export const bloodSugar = [
	{
		date: new Date(2020, 6, 1).toISOString().slice(0, 10),
		count: 130,
	},
	{
		date: new Date(2021, 5, 1).toISOString().slice(0, 10),
		count: 220,
	},
	{
		date: new Date(2021, 7, 1).toISOString().slice(0, 10),
		count: 250,
	},
	{
		date: new Date(2021, 8, 1).toISOString().slice(0, 10),
		count: 300,
	},
	{
		date: new Date(2022, 12, 1).toISOString().slice(0, 10),
		count: 100,
	},
];
