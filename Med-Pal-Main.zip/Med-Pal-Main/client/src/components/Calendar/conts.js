export const DAYS = ["Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun"];

export const MOCKAPPS = [
  { date: new Date(2022, 9, 3), title: "appointment", color: "#238783" },
  { date: new Date(2022, 9, 6), title: "doctos", color: "#708898" },
  { date: new Date(2022, 9, 25), title: "bd", color: "#047106" },
  { date: new Date(2022, 9, 3), title: "second", color: "#371395" }
];
