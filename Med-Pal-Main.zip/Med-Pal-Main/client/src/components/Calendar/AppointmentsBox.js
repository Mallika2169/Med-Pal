const AppointmentsBox = ({appointmentsList})=>{
    
    return(
        <>
        
        </>
    )
}
export default AppointmentsBox;